
export default {
    prismic: {
        api: 'https://nanaschelz.cdn.prismic.io/api/v2',
        documents: {
            bio: 'WyHjDB0AACEAUHji',
            contact: '',
            press: ''
        }
    }
}